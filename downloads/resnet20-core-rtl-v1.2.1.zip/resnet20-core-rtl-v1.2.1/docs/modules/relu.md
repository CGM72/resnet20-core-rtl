# relu.v 선언 사전 — 1.1.1

[모듈 목록·읽는 법](README.md) · [실제 RTL](../../rtl/compute/relu.v) · [파형 확인](../ANALYSIS.md)

음수를 0으로 바꾸고 0/양수는 유지한다. enable=0이면 음수도 그대로 전달한다.

```text
E0: 음수/우회 선택 → pending_data / E1: result_data → out_data
```

표의 비트 수·상수 값은 기본 파라미터 기준입니다. `parameter`는 외부 설정, `localparam`은 내부에서 정해지는 상수입니다.
E0은 입력 수신 상승 에지이며, 출력 시점은 해당 에지의 레지스터 갱신 직후입니다.

## 모듈 `relu`

### 설정 파라미터

| 선언 이름 | 선언 종류·기본 폭/값 | 역할·갱신 시점 |
|---|---|---|
| `BITWIDTH` | parameter / 기본 16 | 입력·출력 데이터 한 개의 비트 수. 기본 signed INT16 범위를 사용한다. |

### 입출력 포트

| 선언 이름 | 선언 종류·기본 폭/값 | 역할·갱신 시점 |
|---|---|---|
| `clk` | input / 1비트 | 데이터를 수신하고 순차 상태를 갱신하는 상승 에지 클럭. |
| `nrst` | input / 1비트 | 0이면 비동기 reset. 유효 표시와 해당 모듈의 상태를 초기화해 진행 중인 계산을 취소한다. |
| `enable` | input / 1비트 | 블록 기능 선택. 1은 연산, 0은 입력을 같은 단계 수로 우회. 입력 유효 표시와는 다르다. |
| `in_enable` | input / 1비트 | 현재 상승 에지에 in_data가 유효하다는 표시. 0인 클럭은 새 입력으로 세지 않는다. |
| `in_data` | input / 16비트 signed | 처리할 입력 한 개. 기본 Q5.10 저장 정수이며, 유효할 때만 연산에 사용한다. |
| `out_enable` | output / 1비트, 조합 전달 | result_valid를 그대로 연결한 최종 유효 표시. |
| `out_data` | output / 16비트 signed, 조합 전달 | result_data를 그대로 연결. 활성 음수는 0, 나머지/우회 값은 입력 그대로다. |

### 내부 데이터·상태·연결 신호

| 선언 이름 | 선언 종류·기본 폭/값 | 역할·갱신 시점 |
|---|---|---|
| `pending_enable` | reg / 1비트 | E0 입력 valid를 저장. 입력 공백도 valid=0으로 전달한다. |
| `pending_data` | reg / signed 16비트 | E0에서 선택한 0 또는 원래 입력. 유효 입력일 때만 갱신한다. |
| `result_valid` | reg / 1비트 | E1에서 pending_enable을 받아 out_enable로 전달하는 결과 valid. |
| `result_data` | reg / signed 16비트 | E1에서 pending_data를 받아 out_data로 전달하는 결과 값. invalid 동안 이전 값을 유지할 수 있다. |

## 코드와 파형을 따라 읽는 예

enable=1에서 -1024→0, 1024→1024. enable=0이면 -1024도 그대로 전달한다. 입력 valid가 끝나도 `result_valid`에는 이전 입력의 결과가 남아 있을 수 있다.

세부 실행 명령과 reset/입력 공백/포화 확인 순서는 상단의 파형 가이드를 따른다.
