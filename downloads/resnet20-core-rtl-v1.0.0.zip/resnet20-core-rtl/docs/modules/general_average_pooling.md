# general_average_pooling.v 선언 사전 — 1.0.0

[모듈 목록·읽는 법](README.md) · [실제 RTL](../../rtl/compute/general_average_pooling.v) · [파형 확인](../waveforms/v1.0.0.md)

같은 채널의 N개 공간 값을 합산해 반올림 평균 하나를 만든다. 입출력 Q scale은 같다.

```text
유효 입력 합산 → 마지막 항 E0: pending_sum/pending_divisor → E1: round_mean/출력
```

표의 비트 수·상수 값은 기본 파라미터 기준입니다. `parameter`는 외부 설정, `localparam`은 내부에서 정해지는 상수입니다.
E0은 입력 수신 상승 에지이며, 출력 시점은 해당 에지의 레지스터 갱신 직후입니다.

## 모듈 `general_average_pooling`

### 설정 파라미터

| 선언 이름 | 선언 종류·기본 폭/값 | 역할·갱신 시점 |
|---|---|---|
| `BITWIDTH` | parameter / 기본 16 | 입력·출력 데이터 한 개의 비트 수. 기본 signed INT16 범위를 사용한다. |
| `BITWIDTH_GAP_ITERATION` | parameter / 기본 16 | GAP 입력 개수 N을 전달하는 iteration 포트의 폭. |

### 입출력 포트

| 선언 이름 | 선언 종류·기본 폭/값 | 역할·갱신 시점 |
|---|---|---|
| `clk` | input / 1비트 | 데이터를 수신하고 순차 상태를 갱신하는 상승 에지 클럭. |
| `nrst` | input / 1비트 | 0이면 비동기 reset. 유효 표시와 해당 모듈의 상태를 초기화해 진행 중인 계산을 취소한다. |
| `enable` | input / 1비트 | 블록 기능 선택. 1은 연산, 0은 입력을 같은 단계 수로 우회. 입력 유효 표시와는 다르다. |
| `in_enable` | input / 1비트 | 현재 상승 에지에 in_data가 유효하다는 표시. 0인 클럭은 새 입력으로 세지 않는다. |
| `iteration` | input / 16비트 unsigned | 평균할 유효 입력 수 N. 양수 N을 지원한다. 0은 입력 폐기/부분합 초기화다. |
| `in_data` | input / 16비트 signed | 처리할 입력 한 개. 기본 Q5.10 저장 정수이며, 유효할 때만 연산에 사용한다. |
| `out_enable` | output / 1비트 | 현재 출력 데이터가 유효하다는 표시. 연속 결과이면 여러 클럭 연속 1일 수 있다. |
| `out_data` | output / 16비트 signed 레지스터 | 입력과 같은 Q scale의 반올림 평균. 마지막 입력 E0 → E1 직후 출력. |

### 내부 폭·상수

| 선언 이름 | 선언 종류·기본 폭/값 | 역할·갱신 시점 |
|---|---|---|
| `WORD_W` | localparam / 값 16 | 입출력 데이터 폭 BITWIDTH의 내부 이름. |
| `ITER_W` | localparam / 값 16 | iteration 포트 폭 BITWIDTH_GAP_ITERATION의 내부 이름. |
| `SUM_W` | localparam / 값 32 | WORD_W+ITER_W. 기본 65535개까지 누산할 여유 폭. |
| `RND_W` | localparam / 값 33 | SUM_W+1. round_mean의 절댓값/반올림 계산 폭. |

### 내부 데이터·상태·연결 신호

| 선언 이름 | 선언 종류·기본 폭/값 | 역할·갱신 시점 |
|---|---|---|
| `accumulator` | reg / signed 32비트, Q10 | 부분합 저장. 마지막 항에서 total을 pending_sum에 넘긴 뒤 0으로 초기화한다. |
| `input_count` | reg / unsigned 16비트 | 현재 그룹에서 먼저 받은 유효 입력 수. 마지막 입력·우회·N=0 입력에서 0이 된다. |
| `pending_enable` | reg / 1비트 | 마지막 입력 또는 우회 값을 S0에 저장했음을 표시. 다음 에지 out_enable이 된다. |
| `pending_sum` | reg / signed 32비트, Q10 | 평균낼 완성된 합. 우회에서는 입력 하나를 저장한다. |
| `pending_divisor` | reg / unsigned 16비트 | pending_sum에 대응하는 분모 N. 우회·reset에서는 1이다. |
| `input_ext` | wire / signed 32비트 | in_data를 합산 폭으로 부호 확장한 값. 평균의 Q scale은 바꾸지 않는다. |
| `total` | wire / signed 32비트, Q10 | accumulator+input_ext의 조합 합. 마지막 입력까지 포함하는 합이다. |

## 함수 `round_mean()`의 인자·지역 변수

함수 안의 `reg`는 조합 계산용 임시 변수이며 클럭 단계를 추가하지 않습니다. 표의 `함수명.변수`는 소속을 구분하는 표기입니다. 실제 소스 안에서는 변수 이름만 사용합니다.

반환값은 signed 16비트입니다. 함수 이름에 대입한 값이 호출부로 반환됩니다.

| 선언 이름 | 종류·기본 폭 | 역할 |
|---|---|---|
| `round_mean.value` | 함수 인자 / signed 32비트, Q10 | 평균낼 합. 호출부의 pending_sum이다. |
| `round_mean.divisor` | 함수 인자 / unsigned 16비트 | 평균의 분모. 호출부의 pending_divisor이다. |
| `round_mean.extended` | 함수 지역 reg / signed 33비트 | 합을 한 비트 부호 확장한 중간 값. |
| `round_mean.magnitude` | 함수 지역 reg / unsigned 33비트 | 부호 확장한 합의 절댓값. |
| `round_mean.denominator` | 함수 지역 reg / unsigned 33비트 | 폭을 맞춘 분모. 0일 때는 조합 나눗셈의 0 나누기를 막기 위해 1로 방어한다. |
| `round_mean.quotient` | 함수 지역 reg / unsigned 33비트 | (magnitude+denominator/2)/denominator로 반올림한 평균 크기. 부호를 복원해 반환한다. |

## 코드와 파형을 따라 읽는 예

N=4에서 [1024,2048,3072,4096]의 합은 10240, 출력은 2560(실수 2.5)이다. N=2에서 [-1,0]→-1: 정확한 절반은 0에서 먼 방향으로 반올림한다.
N=3도 지원하며 [3,6,9]→6이다. `pending_sum`과 `pending_divisor`가 같은 그룹의 값인지 확인한다. 가변 나눗셈은 조합 경로이므로 기능 파형이 맞아도 Timing은 별도 확인해야 한다.

세부 실행 명령과 reset/입력 공백/포화 확인 순서는 상단의 파형 가이드를 따른다.
