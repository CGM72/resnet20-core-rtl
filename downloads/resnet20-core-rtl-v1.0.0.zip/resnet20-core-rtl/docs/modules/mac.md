# mac.v 선언 사전 — 1.0.0

[모듈 목록·읽는 법](README.md) · [실제 RTL](../../rtl/compute/mac.v) · [파형 확인](../waveforms/v1.0.0.md)

한 그룹의 입력×가중치를 더해 내적을 만든다. Conv/FC의 항 순서와 개수는 외부에서 정한다. 같은 파일에 bias=0 wrapper인 mac과 실제 누산 연산부 mac_accumulate가 있다.

```text
곱+누산 → 마지막 항에서 반올림/포화해 pending_data 저장 → out_data
```

표의 비트 수·상수 값은 기본 파라미터 기준입니다. `parameter`는 외부 설정, `localparam`은 내부에서 정해지는 상수입니다.
E0은 입력 수신 상승 에지이며, 출력 시점은 해당 에지의 레지스터 갱신 직후입니다.

## 모듈 `mac`

이 모듈은 내부 `u_accumulate`의 bias를 0으로 고정한다. 출력은 연결선으로 전달하므로 wrapper가 지연을 더하지 않는다.

### 설정 파라미터

| 선언 이름 | 선언 종류·기본 폭/값 | 역할·갱신 시점 |
|---|---|---|
| `BITWIDTH` | parameter / 기본 16 | 입력·출력 데이터 한 개의 비트 수. 기본 signed INT16 범위를 사용한다. |
| `BITWIDTH_MAC_ITERATION` | parameter / 기본 16 | MAC 반복 횟수 포트와 카운터의 폭. 기본 양수 반복 횟수는 1..65535이다. |
| `FRAC_W` | parameter / 기본 10 | 고정소수점의 소수 비트 수. 입력값 1024가 실수 1.0에 해당한다. |

### 입출력 포트

| 선언 이름 | 선언 종류·기본 폭/값 | 역할·갱신 시점 |
|---|---|---|
| `clk` | input / 1비트 | 데이터를 수신하고 순차 상태를 갱신하는 상승 에지 클럭. |
| `nrst` | input / 1비트 | 0이면 비동기 reset. 유효 표시와 해당 모듈의 상태를 초기화해 진행 중인 계산을 취소한다. |
| `enable` | input / 1비트 | 블록 기능 선택. 1은 연산, 0은 입력을 같은 단계 수로 우회. 입력 유효 표시와는 다르다. |
| `in_enable` | input / 1비트 | 현재 상승 에지에 in_data가 유효하다는 표시. 0인 클럭은 새 입력으로 세지 않는다. |
| `iteration` | input / 16비트 unsigned | 그룹당 유효 입력 수 N. 활성 상태의 0은 입력을 폐기하고 부분 그룹을 초기화한다. |
| `in_data` | input / 16비트 signed | 처리할 입력 한 개. 기본 Q5.10 저장 정수이며, 유효할 때만 연산에 사용한다. |
| `kernel_data` | input / 16비트 signed | in_data와 짝을 이루는 가중치. 두 값의 곱은 소수 비트가 20인 Q20이다. |
| `out_enable` | output / 1비트, 조합 전달 | 내부 result_valid를 그대로 내보낸다. 이 wrapper는 별도 출력 레지스터 단계를 추가하지 않는다. |
| `out_data` | output / 16비트 signed, 조합 전달 | 내부 result_data를 그대로 내보낸다. bias는 wrapper 안에서 0으로 고정한다. |

### 내부 데이터·상태·연결 신호

| 선언 이름 | 선언 종류·기본 폭/값 | 역할·갱신 시점 |
|---|---|---|
| `result_valid` | wire / 1비트 | u_accumulate의 out_enable 연결선. wrapper의 out_enable로 전달한다. |
| `result_data` | wire / signed 16비트 | u_accumulate의 out_data 연결선. wrapper의 out_data로 전달한다. |

## 모듈 `mac_accumulate`

core의 `u_mac`이 사용하는 실제 연산부다. `mac` wrapper의 내부에도 같은 모듈이 있다.

### 설정 파라미터

| 선언 이름 | 선언 종류·기본 폭/값 | 역할·갱신 시점 |
|---|---|---|
| `BITWIDTH` | parameter / 기본 16 | 입력·출력 데이터 한 개의 비트 수. 기본 signed INT16 범위를 사용한다. |
| `BITWIDTH_MAC_ITERATION` | parameter / 기본 16 | MAC 반복 횟수 포트와 카운터의 폭. 기본 양수 반복 횟수는 1..65535이다. |
| `FRAC_W` | parameter / 기본 10 | 고정소수점의 소수 비트 수. 입력값 1024가 실수 1.0에 해당한다. |

### 입출력 포트

| 선언 이름 | 선언 종류·기본 폭/값 | 역할·갱신 시점 |
|---|---|---|
| `clk` | input / 1비트 | 데이터를 수신하고 순차 상태를 갱신하는 상승 에지 클럭. |
| `nrst` | input / 1비트 | 0이면 비동기 reset. 유효 표시와 해당 모듈의 상태를 초기화해 진행 중인 계산을 취소한다. |
| `enable` | input / 1비트 | 블록 기능 선택. 1은 연산, 0은 입력을 같은 단계 수로 우회. 입력 유효 표시와는 다르다. |
| `in_enable` | input / 1비트 | 현재 상승 에지에 in_data가 유효하다는 표시. 0인 클럭은 새 입력으로 세지 않는다. |
| `iteration` | input / 16비트 unsigned | 그룹당 유효 입력 수 N. 활성 상태의 0은 입력을 폐기하고 부분 그룹을 초기화한다. |
| `in_data` | input / 16비트 signed | 처리할 입력 한 개. 기본 Q5.10 저장 정수이며, 유효할 때만 연산에 사용한다. |
| `kernel_data` | input / 16비트 signed | in_data와 짝을 이루는 가중치. 두 값의 곱은 소수 비트가 20인 Q20이다. |
| `bias_data` | input / 16비트 signed | 그룹의 첫 항에서만 사용하는 bias. 누산할 때 FRAC_W만큼 왼쪽으로 옮겨 곱의 단위에 맞춘다. |
| `last_input` | output / 1비트 조합 | enable=1, 유효 입력, N>0, input_count=N-1일 때 1. core가 다음 입력을 skip으로 구분하는 경계다. |
| `out_enable` | output / 1비트 레지스터 | pending_enable을 전달한 결과 valid. 마지막 항 E0 기준 E1 직후 유효. |
| `out_data` | output / 16비트 signed 레지스터 | 최종 내적을 Q5.10으로 반올림하고 -32768..32767로 포화한 결과. enable=0이면 입력을 전달한다. |

### 내부 폭·상수

| 선언 이름 | 선언 종류·기본 폭/값 | 역할·갱신 시점 |
|---|---|---|
| `WORD_W` | localparam / 값 16 | 데이터 폭의 내부 이름. BITWIDTH와 같다. |
| `ITER_W` | localparam / 값 16 | 반복 횟수/입력 카운터 폭. BITWIDTH_MAC_ITERATION과 같다. |
| `PROD_W` | localparam / 값 32 | 곱의 폭. WORD_W+WORD_W로 두 입력의 곱을 보존한다. |
| `ACC_W` | localparam / 값 48 | 누산 폭. PROD_W+ITER_W로 반복 누산의 여유 비트를 확보한다. |
| `RND_W` | localparam / 값 49 | round_shift 함수의 계산 폭. ACC_W+1로 음수 최솟값도 절댓값으로 표현한다. |
| `ONE` | localparam / unsigned 49비트, 값 1 | 원하는 폭에서 HALF를 만드는 기준값. |
| `HALF` | localparam / 값 512 | FRAC_W=10의 반올림 보정값. 정확한 절반은 0에서 먼 방향으로 처리한다. |
| `SAT_MAX` | localparam / signed 48비트, 값 32767 | saturate 함수가 출력 양수 범위를 판단하는 상한. |
| `SAT_MIN` | localparam / signed 48비트, 값 -32768 | saturate 함수가 출력 음수 범위를 판단하는 하한. |

### 내부 데이터·상태·연결 신호

| 선언 이름 | 선언 종류·기본 폭/값 | 역할·갱신 시점 |
|---|---|---|
| `accumulator` | reg / signed 48비트, Q20 | 첫 항 뒤부터 부분합을 저장한다. 마지막 항·우회·N=0·reset에서 0으로 지운다. |
| `input_count` | reg / unsigned 16비트 | 현재 그룹에서 먼저 받은 유효 항 수(0..N-1). 마지막 항·우회·N=0에서 0으로 돌아간다. |
| `pending_enable` | reg / 1비트 | 이번 에지에 결과를 만들었음을 저장. 마지막 항/우회에서 1, 다음 에지 출력 valid가 된다. |
| `pending_data` | reg / signed 16비트, Q10 | 마지막 항에서 round_shift와 saturate를 거친 값 또는 우회 입력. |
| `product` | wire / signed 32비트, Q20 | 현재 in_data×kernel_data의 조합 곱. 유효 입력일 때 누산에 사용한다. |
| `product_ext` | wire / signed 48비트 | 32비트 곱의 부호를 유지하며 누산 폭으로 늘린 값. |
| `bias_ext` | wire / signed 48비트 | bias를 누산 폭으로 부호 확장한 값. 왼쪽 shift 후 Q20 단위가 된다. |
| `base_sum` | wire / signed 48비트, Q20 | input_count=0이면 bias_ext<<FRAC_W, 이후면 accumulator를 선택한다. |
| `total` | wire / signed 48비트, Q20 | 현재 항의 곱을 base_sum에 더한 값. 마지막 항도 포함한 합이다. |

## 함수 `round_shift()`의 인자·지역 변수

함수 안의 `reg`는 조합 계산용 임시 변수이며 클럭 단계를 추가하지 않습니다. 표의 `함수명.변수`는 소속을 구분하는 표기입니다. 실제 소스 안에서는 변수 이름만 사용합니다.

반환값은 signed 48비트 Q10이며 아직 INT16 포화 전입니다.

| 선언 이름 | 종류·기본 폭 | 역할 |
|---|---|---|
| `round_shift.value` | 함수 인자 / signed 48비트, Q20 | 마지막 항까지 포함한 누산 합. 함수는 이 값을 Q10으로 반올림해 반환한다. |
| `round_shift.extended` | 함수 지역 reg / signed 49비트 | value를 한 비트 부호 확장. 음수 최솟값의 절댓값도 표현하기 위한 중간 값. |
| `round_shift.magnitude` | 함수 지역 reg / unsigned 49비트 | extended의 절댓값. |
| `round_shift.rounded` | 함수 지역 reg / unsigned 49비트, Q10 | (magnitude+HALF)>>FRAC_W. 원래 부호를 복원해 반환한다. |

## 함수 `saturate()`의 인자·지역 변수

함수 안의 `reg`는 조합 계산용 임시 변수이며 클럭 단계를 추가하지 않습니다. 표의 `함수명.변수`는 소속을 구분하는 표기입니다. 실제 소스 안에서는 변수 이름만 사용합니다.

반환값은 signed 16비트입니다. 함수 이름에 대입한 값이 호출부로 반환됩니다.

| 선언 이름 | 종류·기본 폭 | 역할 |
|---|---|---|
| `saturate.value` | 함수 인자 / signed 48비트, Q10 | 반올림 후 값. INT16 범위를 벗어나면 SAT_MAX/SAT_MIN으로 제한한다. |

## 코드와 파형을 따라 읽는 예

bias를 받는 mac_accumulate/core의 예입니다. N=2, 입력과 가중치가 두 항 모두 1024, 첫 항 bias=1024이면 최종 저장 정수는 3072(실수 3.0)다. 두 번째 항의 bias는 합에 추가하지 않는다. bias가 0으로 고정된 mac wrapper에서는 같은 입력의 결과가 2048이다.
마지막 항 E0 기준 E1 직후 출력한다. 입출력은 Q10, 곱/누산은 Q20이므로 파형 숫자를 같은 배율로 읽지 않는다.
마지막 항에서는 `total`에 현재 곱까지 더한 뒤 함수 두 개를 거쳐 결과를 만든다. 함수가 여러 클럭으로 나뉘어 실행되는 것은 아니다.

세부 실행 명령과 reset/입력 공백/포화 확인 순서는 상단의 파형 가이드를 따른다.
